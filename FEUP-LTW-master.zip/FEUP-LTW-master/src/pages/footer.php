<!-- begin footer -->


<footer>
    <div class="footer">
        <p class="workdoneby">
            Daniel Gazola Bradaschia - Gustavo Speranzini Tosi Tavares - Paulo André Areias Gomes Leal Pinto
        </p>
    </div>
</footer>
</html>