<?php

$db = new PDO('sqlite:../criar.db');

